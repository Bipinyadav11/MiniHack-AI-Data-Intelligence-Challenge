
# MiniHack AI Data Intelligence Challenge
# Complete Question-Wise Solution

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import ttest_ind

df = pd.read_csv("last_mile_delivery_dataset.csv")

# ================= Q1 =================
df["hour"] = pd.to_datetime(df["order_time"]).dt.hour
peak = df[((df["hour"] >= 8) & (df["hour"] < 10)) |
          ((df["hour"] >= 17) & (df["hour"] < 20))]
off_peak = df.drop(peak.index)

print("Q1")
print("Average Peak Hour Delay:", round(peak["delay_mins"].mean(),2))
print("Average Off Peak Delay:", round(off_peak["delay_mins"].mean(),2))

# ================= Q2 =================
print("\nQ2")
weather_delay = df.groupby("weather_condition")["delay_mins"].median()
print(weather_delay)

rain = df[df["weather_condition"]=="Rain"]
print(rain.groupby("order_type")["delay_mins"].median().sort_values(ascending=False))

# ================= Q3 =================
print("\nQ3")
less_2 = df[df["rider_experience_yrs"]<2]["delay_mins"]
more_4 = df[df["rider_experience_yrs"]>4]["delay_mins"]
t_stat, p_value = ttest_ind(less_2, more_4, equal_var=False)
print("P-value:", p_value)

# ================= Q4 =================
print("\nQ4")
df["on_time"] = np.where(df["delay_mins"]<=10,1,0)

city_rate = df.groupby("city")["on_time"].mean()*100
city_rate.plot(kind="bar", title="City-wise On-Time Delivery Rate")
plt.show()

df["month"] = pd.to_datetime(df["order_date"]).dt.month_name()
monthly = df.groupby("month")["delay_mins"].mean()
monthly.plot(marker="o", title="Monthly Delay Trend")
plt.show()

vehicle = df.groupby("vehicle_type")["delay_mins"].mean()
vehicle.plot(kind="bar", title="Vehicle Type Comparison")
plt.show()
